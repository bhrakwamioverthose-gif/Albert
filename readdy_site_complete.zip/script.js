
// Basic local demo: intercept form submit and show an alert.
// Replace with real form handler for production.
document.getElementById('contactForm').addEventListener('submit', function(e){
  e.preventDefault();
  alert('Demo: form captured. On a live site connect to Formspree, Netlify Forms or an email endpoint.');
});
