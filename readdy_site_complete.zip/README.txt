
README — Completed static site
Files:
  - index.html
  - styles.css
  - script.js
  - assets/preview.png

What this is:
  - A polished single-page static website rebuilt so you can host it without Readdy subscription walls.

How to edit:
  - Open index.html in a text editor and replace text/images.
  - Styles in styles.css. JS in script.js.

How to deploy (quick):
  - GitHub Pages: create a repo, push these files to the main branch, enable Pages in repo settings.
  - Netlify: drag & drop the folder in Netlify dashboard, or connect the GitHub repo.
  - Vercel: import the repo; Vercel auto-detects static sites.

Make the contact form work:
  - Use Formspree (https://formspree.io) or Netlify Forms. Replace the <form> action or follow their instructions.

If you want me to:
  - Replace the placeholder text/images with content from your Readdy project (paste text or upload images here).
  - Customize colors, font choices, or add extra pages (pricing, blog, etc).
  - Create a zip with your custom changes and provide it for download.
